import { GET_CARS_API } from "../../config/constants"
import type { Car } from "../../types/car"

type ApiResponse<T> = { sucsess: boolean; data: T }

const cars = async (type?: string, deal?: string, availability?: string) => {
  const params = new URLSearchParams()

  if (type) params.set("type", type)
  if (deal) params.set("deal", deal)
  if (availability) params.set("availability", availability)

  const qs = params.toString()
  const url = qs ? `${GET_CARS_API}?${qs}` : GET_CARS_API

  const res = await fetch(url, { method: "GET" })
  if (!res.ok) {
    throw new Error("failed to fetch cars")
  }
  const json: ApiResponse<Car[]> = await res.json()
  return json.data
}
export default cars
