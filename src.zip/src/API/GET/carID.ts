import { GET_CAR_W_ID_API } from "../../config/constants"
import type { Car } from "../../types/car"

type ApiResponse<T> = { success: boolean; data: T }

const carID = async (ID: string) => {
  const res = await fetch(`${GET_CAR_W_ID_API}/${ID}`, {
    method: "GET",
  })
  if (!res.ok) {
    throw new Error("failed to fetch carID")
  }
  const json: ApiResponse<Car | null> = await res.json()
  return json.data
}
export default carID
